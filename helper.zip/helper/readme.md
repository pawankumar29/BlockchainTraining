# Web3 by Example

Learn how to use web3.js with these examples!

Follow the step-by-step tutorial series on my Youtube channel here:

https://www.youtube.com/playlist?list=PLS5SEs8ZftgXlCGXNfzKdq7nGBcIaVOdN

## Getting Started
Install dependencies.

`$ npm install`

Run the sandbox `app.js` file with your code examples:

`$ node app.js`

See the code examples in the `./examples` directory for inspiration! :)
