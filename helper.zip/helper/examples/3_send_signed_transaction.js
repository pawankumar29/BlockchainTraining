const Web3 = require('web3');
var Tx= require('ethereumjs-tx')

const rpcURL = 'http://127.0.0.1:7545';
const web3 = new Web3(new Web3.providers.HttpProvider(rpcURL));

const account1 = '0xc415367E5DD66b1CCa6b806Dc52C0Ad208bDd4c2'; // Your account address 1
const account2 = '0x9A3b6b351120fB0FBcf7b10518B9aF8942CC4d14'; // Your account address 2

const privateKey1 = Buffer.from('54001f78d71b3efa6dd2f8bec37cd99197edf263e0e8276d19340b6710261202', 'hex');
const privateKey2 = Buffer.from('54d85af01acd5f218caeece9aa2669d16954fd7f804fe477f2a24ec598e46785', 'hex');

(async () => {
  try {
    const txCount = await web3.eth.getTransactionCount(account1);

    const txObject = {
      nonce: web3.utils.toHex(txCount),
      to: account2,
      value: web3.utils.toHex(web3.utils.toWei('0.1', 'ether')),
      gasLimit: web3.utils.toHex(21000),
      gasPrice: web3.utils.toHex(web3.utils.toWei('10', 'gwei'))
    };// everything shoul be in hex

    const tx = new Tx(txObject);
    tx.sign(privateKey1);

    const serializedTx = tx.serialize();
    const raw = '0x' + serializedTx.toString('hex');// convert into hexa string for broadcasting 

    const receipt = await web3.eth.sendSignedTransaction(raw);
    console.log('Transaction receipt:', receipt);
  } catch (error) {
    console.error('Error sending transaction:', error);
  }
})();
