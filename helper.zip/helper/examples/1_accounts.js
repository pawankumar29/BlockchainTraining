const Web3 = require('web3');

// Use lowercase 'http' instead of 'HTTP'
const rpcURL = 'http://127.0.0.1:7545';

const web3 = new Web3(new Web3.providers.HttpProvider(rpcURL));

const address = '0xc415367E5DD66b1CCa6b806Dc52C0Ad208bDd4c2'; // Your account address goes here

(async () => {
  try {
    const wei = await web3.eth.getBalance(address);
    const balance = web3.utils.fromWei(wei, 'ether');
    console.log('Balance:', balance);
  } catch (err) {
    console.error('Error:', err);
  }
})();
